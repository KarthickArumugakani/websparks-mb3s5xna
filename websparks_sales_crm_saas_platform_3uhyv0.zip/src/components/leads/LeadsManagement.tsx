import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { Lead } from '../../types';
import Button from '../common/Button';
import Card from '../common/Card';
import Modal from '../common/Modal';
import Input from '../common/Input';
import Select from '../common/Select';
import LeadForm from './LeadForm';
import BulkUpload from './BulkUpload';

const LeadsManagement: React.FC = () => {
  const { user } = useAuth();
  const { leads, users, deleteLead } = useData();
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showBulkUpload, setShowBulkUpload] = useState(false);
  const [editingLead, setEditingLead] = useState<Lead | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [stageFilter, setStageFilter] = useState('');

  // Filter leads based on user role
  const getFilteredLeads = () => {
    let filteredLeads = leads;

    if (user?.role === 'user') {
      filteredLeads = leads.filter(lead => lead.assignedTo === user.id);
    } else if (user?.role === 'manager') {
      const teamMembers = users.filter(u => u.managerId === user.id);
      const teamIds = [user.id, ...teamMembers.map(u => u.id)];
      filteredLeads = leads.filter(lead => teamIds.includes(lead.assignedTo));
    }

    // Apply search and filters
    if (searchTerm) {
      filteredLeads = filteredLeads.filter(lead =>
        lead.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        lead.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        lead.mobile.includes(searchTerm)
      );
    }

    if (statusFilter) {
      filteredLeads = filteredLeads.filter(lead => lead.status === statusFilter);
    }

    if (stageFilter) {
      filteredLeads = filteredLeads.filter(lead => lead.stage === stageFilter);
    }

    return filteredLeads;
  };

  const filteredLeads = getFilteredLeads();

  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case 'hot': return 'bg-red-100 text-red-800';
      case 'warm': return 'bg-yellow-100 text-yellow-800';
      case 'cold': return 'bg-blue-100 text-blue-800';
      default: return 'bg-secondary-100 text-secondary-800';
    }
  };

  const getStageBadgeColor = (stage: string) => {
    switch (stage) {
      case 'initial': return 'bg-purple-100 text-purple-800';
      case 'negotiation': return 'bg-orange-100 text-orange-800';
      case 'follow-up': return 'bg-blue-100 text-blue-800';
      case 'closed-won': return 'bg-green-100 text-green-800';
      case 'closed-lost': return 'bg-red-100 text-red-800';
      default: return 'bg-secondary-100 text-secondary-800';
    }
  };

  const getUserName = (userId: string) => {
    const foundUser = users.find(u => u.id === userId);
    return foundUser ? foundUser.name : 'Unknown';
  };

  const handleDelete = (leadId: string) => {
    if (window.confirm('Are you sure you want to delete this lead?')) {
      deleteLead(leadId);
    }
  };

  const statusOptions = [
    { value: '', label: 'All Status' },
    { value: 'hot', label: 'Hot' },
    { value: 'warm', label: 'Warm' },
    { value: 'cold', label: 'Cold' },
  ];

  const stageOptions = [
    { value: '', label: 'All Stages' },
    { value: 'initial', label: 'Initial' },
    { value: 'negotiation', label: 'Negotiation' },
    { value: 'follow-up', label: 'Follow Up' },
    { value: 'closed-won', label: 'Closed Won' },
    { value: 'closed-lost', label: 'Closed Lost' },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-secondary-900">Leads Management</h2>
        <div className="flex space-x-3">
          <Button variant="secondary" onClick={() => setShowBulkUpload(true)}>
            <i className="bi bi-upload mr-2"></i>
            Bulk Upload
          </Button>
          <Button onClick={() => setShowCreateModal(true)}>
            <i className="bi bi-plus-lg mr-2"></i>
            Add Lead
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Input
            placeholder="Search leads..."
            value={searchTerm}
            onChange={setSearchTerm}
          />
          <Select
            value={statusFilter}
            onChange={setStatusFilter}
            options={statusOptions}
            placeholder="Filter by status"
          />
          <Select
            value={stageFilter}
            onChange={setStageFilter}
            options={stageOptions}
            placeholder="Filter by stage"
          />
          <Button
            variant="secondary"
            onClick={() => {
              setSearchTerm('');
              setStatusFilter('');
              setStageFilter('');
            }}
          >
            <i className="bi bi-arrow-clockwise mr-2"></i>
            Reset
          </Button>
        </div>
      </Card>

      {/* Leads Table */}
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-secondary-200">
                <th className="text-left py-3 px-4 font-semibold text-secondary-900">Lead</th>
                <th className="text-left py-3 px-4 font-semibold text-secondary-900">Contact</th>
                <th className="text-left py-3 px-4 font-semibold text-secondary-900">Status</th>
                <th className="text-left py-3 px-4 font-semibold text-secondary-900">Stage</th>
                <th className="text-left py-3 px-4 font-semibold text-secondary-900">Assigned To</th>
                <th className="text-left py-3 px-4 font-semibold text-secondary-900">Value</th>
                <th className="text-left py-3 px-4 font-semibold text-secondary-900">Created</th>
                <th className="text-left py-3 px-4 font-semibold text-secondary-900">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredLeads.map((lead) => (
                <tr key={lead.id} className="border-b border-secondary-100 hover:bg-secondary-50 transition-colors duration-200">
                  <td className="py-3 px-4">
                    <div>
                      <p className="font-medium text-secondary-900">{lead.name}</p>
                      {lead.notes && (
                        <p className="text-sm text-secondary-600 truncate max-w-xs">{lead.notes}</p>
                      )}
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="text-sm">
                      <p className="text-secondary-900">{lead.email}</p>
                      <p className="text-secondary-600">{lead.mobile}</p>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusBadgeColor(lead.status)}`}>
                      {lead.status.toUpperCase()}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStageBadgeColor(lead.stage)}`}>
                      {lead.stage.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-sm text-secondary-900">
                    {getUserName(lead.assignedTo)}
                  </td>
                  <td className="py-3 px-4 text-sm text-secondary-900">
                    {lead.value ? `$${lead.value.toLocaleString()}` : '-'}
                  </td>
                  <td className="py-3 px-4 text-sm text-secondary-600">
                    {new Date(lead.createdAt).toLocaleDateString()}
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex space-x-2">
                      <button
                        onClick={() => setEditingLead(lead)}
                        className="text-primary-600 hover:text-primary-700 transition-colors duration-200"
                      >
                        <i className="bi bi-pencil"></i>
                      </button>
                      <button
                        onClick={() => handleDelete(lead.id)}
                        className="text-red-600 hover:text-red-700 transition-colors duration-200"
                      >
                        <i className="bi bi-trash"></i>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {filteredLeads.length === 0 && (
            <div className="text-center py-8">
              <i className="bi bi-inbox text-4xl text-secondary-400 mb-4"></i>
              <p className="text-secondary-600">No leads found</p>
            </div>
          )}
        </div>
      </Card>

      {/* Create Lead Modal */}
      <Modal
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        title="Create New Lead"
        size="lg"
      >
        <LeadForm
          onSubmit={() => setShowCreateModal(false)}
          onCancel={() => setShowCreateModal(false)}
        />
      </Modal>

      {/* Edit Lead Modal */}
      <Modal
        isOpen={!!editingLead}
        onClose={() => setEditingLead(null)}
        title="Edit Lead"
        size="lg"
      >
        {editingLead && (
          <LeadForm
            lead={editingLead}
            onSubmit={() => setEditingLead(null)}
            onCancel={() => setEditingLead(null)}
          />
        )}
      </Modal>

      {/* Bulk Upload Modal */}
      <Modal
        isOpen={showBulkUpload}
        onClose={() => setShowBulkUpload(false)}
        title="Bulk Upload Leads"
        size="lg"
      >
        <BulkUpload type="leads" onClose={() => setShowBulkUpload(false)} />
      </Modal>
    </div>
  );
};

export default LeadsManagement;
