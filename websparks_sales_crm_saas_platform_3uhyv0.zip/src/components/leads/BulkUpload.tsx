import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { useAuth } from '../../context/AuthContext';
import Button from '../common/Button';
import Card from '../common/Card';
import Papa from 'papaparse';
import toast from 'react-hot-toast';

interface BulkUploadProps {
  type: 'users' | 'leads';
  onClose: () => void;
}

const BulkUpload: React.FC<BulkUploadProps> = ({ type, onClose }) => {
  const { bulkUploadUsers, bulkUploadLeads } = useData();
  const { user } = useAuth();
  const [file, setFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile && selectedFile.type === 'text/csv') {
      setFile(selectedFile);
    } else {
      toast.error('Please select a valid CSV file');
    }
  };

  const handleUpload = () => {
    if (!file) {
      toast.error('Please select a file');
      return;
    }

    setIsUploading(true);

    Papa.parse(file, {
      header: true,
      complete: (results) => {
        try {
          if (type === 'users') {
            const userData = results.data.map((row: any) => ({
              name: row.name || '',
              email: row.email || '',
              role: row.role || 'user',
              managerId: row.managerId || (user?.role === 'manager' ? user.id : undefined),
              isActive: true,
            })).filter(u => u.name && u.email);

            bulkUploadUsers(userData);
          } else {
            const leadData = results.data.map((row: any) => ({
              name: row.name || '',
              email: row.email || '',
              mobile: row.mobile || '',
              status: row.status || 'warm',
              stage: row.stage || 'initial',
              assignedTo: row.assignedTo || user?.id || '',
              createdBy: user?.id || '',
              notes: row.notes || '',
              value: row.value ? parseFloat(row.value) : undefined,
            })).filter(l => l.name && l.email && l.mobile);

            bulkUploadLeads(leadData);
          }

          onClose();
        } catch (error) {
          toast.error('Error processing file');
        } finally {
          setIsUploading(false);
        }
      },
      error: () => {
        toast.error('Error reading file');
        setIsUploading(false);
      }
    });
  };

  const downloadTemplate = () => {
    let csvContent = '';
    
    if (type === 'users') {
      csvContent = 'name,email,role,managerId\nJohn Doe,john@example.com,user,\nJane Smith,jane@example.com,manager,';
    } else {
      csvContent = 'name,email,mobile,status,stage,assignedTo,notes,value\nAcme Corp,contact@acme.com,+1234567890,hot,initial,,Great potential client,50000\nTech Solutions,info@tech.com,+1234567891,warm,follow-up,,Follow up next week,25000';
    }

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${type}_template.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  return (
    <Card>
      <div className="space-y-6">
        <div className="text-center">
          <i className={`bi ${type === 'users' ? 'bi-people' : 'bi-person-lines-fill'} text-4xl text-primary-600 mb-4`}></i>
          <h3 className="text-lg font-semibold text-secondary-900 mb-2">
            Bulk Upload {type === 'users' ? 'Users' : 'Leads'}
          </h3>
          <p className="text-secondary-600">
            Upload a CSV file to add multiple {type} at once
          </p>
        </div>

        <div className="border-2 border-dashed border-secondary-300 rounded-lg p-6 text-center">
          <input
            type="file"
            accept=".csv"
            onChange={handleFileChange}
            className="hidden"
            id="file-upload"
          />
          <label
            htmlFor="file-upload"
            className="cursor-pointer flex flex-col items-center space-y-2"
          >
            <i className="bi bi-cloud-upload text-3xl text-secondary-400"></i>
            <span className="text-secondary-600">
              {file ? file.name : 'Click to select CSV file'}
            </span>
          </label>
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <h4 className="font-medium text-blue-900 mb-2">CSV Format Requirements:</h4>
          <ul className="text-sm text-blue-800 space-y-1">
            {type === 'users' ? (
              <>
                <li>• Required columns: name, email, role</li>
                <li>• Optional columns: managerId</li>
                <li>• Valid roles: user, manager, admin</li>
              </>
            ) : (
              <>
                <li>• Required columns: name, email, mobile</li>
                <li>• Optional columns: status, stage, assignedTo, notes, value</li>
                <li>• Valid status: hot, warm, cold</li>
                <li>• Valid stages: initial, negotiation, follow-up, closed-won, closed-lost</li>
              </>
            )}
          </ul>
        </div>

        <div className="flex justify-between items-center">
          <Button variant="secondary" onClick={downloadTemplate}>
            <i className="bi bi-download mr-2"></i>
            Download Template
          </Button>

          <div className="space-x-3">
            <Button variant="secondary" onClick={onClose}>
              Cancel
            </Button>
            <Button onClick={handleUpload} disabled={!file || isUploading}>
              {isUploading ? (
                <>
                  <i className="bi bi-arrow-clockwise animate-spin mr-2"></i>
                  Uploading...
                </>
              ) : (
                <>
                  <i className="bi bi-upload mr-2"></i>
                  Upload
                </>
              )}
            </Button>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default BulkUpload;
