import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { Lead } from '../../types';
import Input from '../common/Input';
import Select from '../common/Select';
import Button from '../common/Button';

interface LeadFormProps {
  lead?: Lead;
  onSubmit: () => void;
  onCancel: () => void;
}

const LeadForm: React.FC<LeadFormProps> = ({ lead, onSubmit, onCancel }) => {
  const { user } = useAuth();
  const { users, addLead, updateLead } = useData();
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    mobile: '',
    status: 'warm' as 'hot' | 'warm' | 'cold',
    stage: 'initial' as 'initial' | 'negotiation' | 'follow-up' | 'closed-won' | 'closed-lost',
    assignedTo: '',
    notes: '',
    value: '',
  });

  useEffect(() => {
    if (lead) {
      setFormData({
        name: lead.name,
        email: lead.email,
        mobile: lead.mobile,
        status: lead.status,
        stage: lead.stage,
        assignedTo: lead.assignedTo,
        notes: lead.notes || '',
        value: lead.value?.toString() || '',
      });
    } else {
      setFormData(prev => ({
        ...prev,
        assignedTo: user?.id || '',
      }));
    }
  }, [lead, user]);

  const getAssignableUsers = () => {
    if (user?.role === 'owner' || user?.role === 'admin') {
      return users.filter(u => u.role !== 'owner');
    }
    if (user?.role === 'manager') {
      const teamMembers = users.filter(u => u.managerId === user.id || u.id === user.id);
      return teamMembers;
    }
    return users.filter(u => u.id === user?.id);
  };

  const assignableUsers = getAssignableUsers();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const leadData = {
      name: formData.name,
      email: formData.email,
      mobile: formData.mobile,
      status: formData.status,
      stage: formData.stage,
      assignedTo: formData.assignedTo,
      createdBy: user?.id || '',
      notes: formData.notes,
      value: formData.value ? parseFloat(formData.value) : undefined,
    };

    if (lead) {
      updateLead(lead.id, leadData);
    } else {
      addLead(leadData);
    }
    
    onSubmit();
  };

  const statusOptions = [
    { value: 'hot', label: 'Hot' },
    { value: 'warm', label: 'Warm' },
    { value: 'cold', label: 'Cold' },
  ];

  const stageOptions = [
    { value: 'initial', label: 'Initial' },
    { value: 'negotiation', label: 'Negotiation' },
    { value: 'follow-up', label: 'Follow Up' },
    { value: 'closed-won', label: 'Closed Won' },
    { value: 'closed-lost', label: 'Closed Lost' },
  ];

  const userOptions = assignableUsers.map(u => ({
    value: u.id,
    label: `${u.name} (${u.role})`,
  }));

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input
          label="Lead Name"
          value={formData.name}
          onChange={(value) => setFormData(prev => ({ ...prev, name: value }))}
          placeholder="Enter lead name"
          required
        />

        <Input
          label="Email"
          type="email"
          value={formData.email}
          onChange={(value) => setFormData(prev => ({ ...prev, email: value }))}
          placeholder="Enter email address"
          required
        />

        <Input
          label="Mobile Number"
          value={formData.mobile}
          onChange={(value) => setFormData(prev => ({ ...prev, mobile: value }))}
          placeholder="Enter mobile number"
          required
        />

        <Input
          label="Lead Value"
          type="number"
          value={formData.value}
          onChange={(value) => setFormData(prev => ({ ...prev, value: value }))}
          placeholder="Enter lead value"
        />

        <Select
          label="Status"
          value={formData.status}
          onChange={(value) => setFormData(prev => ({ ...prev, status: value as any }))}
          options={statusOptions}
          required
        />

        <Select
          label="Stage"
          value={formData.stage}
          onChange={(value) => setFormData(prev => ({ ...prev, stage: value as any }))}
          options={stageOptions}
          required
        />

        <Select
          label="Assigned To"
          value={formData.assignedTo}
          onChange={(value) => setFormData(prev => ({ ...prev, assignedTo: value }))}
          options={userOptions}
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-secondary-700 mb-2">
          Notes
        </label>
        <textarea
          value={formData.notes}
          onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
          placeholder="Enter additional notes"
          rows={3}
          className="w-full px-3 py-2 border border-secondary-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all duration-200"
        />
      </div>

      <div className="flex justify-end space-x-3 pt-4">
        <Button variant="secondary" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit">
          {lead ? 'Update Lead' : 'Create Lead'}
        </Button>
      </div>
    </form>
  );
};

export default LeadForm;
