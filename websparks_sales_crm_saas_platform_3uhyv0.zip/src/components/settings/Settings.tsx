import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import Card from '../common/Card';
import Button from '../common/Button';
import Input from '../common/Input';
import Select from '../common/Select';
import Modal from '../common/Modal';
import toast from 'react-hot-toast';

const Settings: React.FC = () => {
  const { user } = useAuth();
  const { users, leads } = useData();
  const [activeSection, setActiveSection] = useState('profile');
  const [showBackupModal, setShowBackupModal] = useState(false);
  const [showRestoreModal, setShowRestoreModal] = useState(false);

  // Profile Settings
  const [profileData, setProfileData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });

  // System Settings
  const [systemSettings, setSystemSettings] = useState({
    companyName: 'SalesPro CRM',
    timezone: 'UTC',
    dateFormat: 'MM/DD/YYYY',
    currency: 'USD',
    language: 'en',
    emailNotifications: true,
    smsNotifications: false,
    autoAssignLeads: true,
    leadRetentionDays: '365',
    maxUsersPerManager: '10',
  });

  // Security Settings
  const [securitySettings, setSecuritySettings] = useState({
    passwordMinLength: '8',
    requireSpecialChars: true,
    sessionTimeout: '60',
    twoFactorAuth: false,
    loginAttempts: '5',
    accountLockoutTime: '30',
  });

  const menuItems = [
    { id: 'profile', label: 'Profile Settings', icon: 'bi-person-circle', roles: ['owner', 'admin', 'manager', 'user'] },
    { id: 'system', label: 'System Settings', icon: 'bi-gear', roles: ['owner', 'admin'] },
    { id: 'security', label: 'Security Settings', icon: 'bi-shield-check', roles: ['owner', 'admin'] },
    { id: 'notifications', label: 'Notifications', icon: 'bi-bell', roles: ['owner', 'admin', 'manager', 'user'] },
    { id: 'data', label: 'Data Management', icon: 'bi-database', roles: ['owner', 'admin'] },
    { id: 'integrations', label: 'Integrations', icon: 'bi-plug', roles: ['owner', 'admin'] },
  ];

  const filteredMenuItems = menuItems.filter(item => 
    user && item.roles.includes(user.role)
  );

  const handleProfileUpdate = () => {
    if (profileData.newPassword && profileData.newPassword !== profileData.confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }

    // In a real app, this would make an API call
    toast.success('Profile updated successfully');
    setProfileData(prev => ({ ...prev, currentPassword: '', newPassword: '', confirmPassword: '' }));
  };

  const handleSystemSettingsUpdate = () => {
    // In a real app, this would make an API call
    localStorage.setItem('systemSettings', JSON.stringify(systemSettings));
    toast.success('System settings updated successfully');
  };

  const handleSecuritySettingsUpdate = () => {
    // In a real app, this would make an API call
    localStorage.setItem('securitySettings', JSON.stringify(securitySettings));
    toast.success('Security settings updated successfully');
  };

  const handleBackupData = () => {
    const backupData = {
      users,
      leads,
      systemSettings,
      securitySettings,
      exportedAt: new Date().toISOString(),
      version: '1.0.0'
    };

    const dataStr = JSON.stringify(backupData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `crm-backup-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
    
    setShowBackupModal(false);
    toast.success('Data backup downloaded successfully');
  };

  const handleRestoreData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const backupData = JSON.parse(e.target?.result as string);
        
        // Validate backup data structure
        if (!backupData.users || !backupData.leads) {
          toast.error('Invalid backup file format');
          return;
        }

        // In a real app, this would restore to the database
        localStorage.setItem('crmUsers', JSON.stringify(backupData.users));
        localStorage.setItem('crmLeads', JSON.stringify(backupData.leads));
        
        if (backupData.systemSettings) {
          localStorage.setItem('systemSettings', JSON.stringify(backupData.systemSettings));
          setSystemSettings(backupData.systemSettings);
        }
        
        if (backupData.securitySettings) {
          localStorage.setItem('securitySettings', JSON.stringify(backupData.securitySettings));
          setSecuritySettings(backupData.securitySettings);
        }

        setShowRestoreModal(false);
        toast.success('Data restored successfully. Please refresh the page.');
      } catch (error) {
        toast.error('Error reading backup file');
      }
    };
    reader.readAsText(file);
  };

  const clearAllData = () => {
    if (window.confirm('Are you sure you want to clear all data? This action cannot be undone.')) {
      localStorage.removeItem('crmUsers');
      localStorage.removeItem('crmLeads');
      localStorage.removeItem('systemSettings');
      localStorage.removeItem('securitySettings');
      toast.success('All data cleared. Please refresh the page.');
    }
  };

  const renderProfileSettings = () => (
    <div className="space-y-6">
      <Card>
        <h3 className="text-lg font-semibold text-secondary-900 mb-4">Personal Information</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input
            label="Full Name"
            value={profileData.name}
            onChange={(value) => setProfileData(prev => ({ ...prev, name: value }))}
            placeholder="Enter your full name"
          />
          <Input
            label="Email Address"
            type="email"
            value={profileData.email}
            onChange={(value) => setProfileData(prev => ({ ...prev, email: value }))}
            placeholder="Enter your email"
          />
        </div>
      </Card>

      <Card>
        <h3 className="text-lg font-semibold text-secondary-900 mb-4">Change Password</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Input
            label="Current Password"
            type="password"
            value={profileData.currentPassword}
            onChange={(value) => setProfileData(prev => ({ ...prev, currentPassword: value }))}
            placeholder="Enter current password"
          />
          <Input
            label="New Password"
            type="password"
            value={profileData.newPassword}
            onChange={(value) => setProfileData(prev => ({ ...prev, newPassword: value }))}
            placeholder="Enter new password"
          />
          <Input
            label="Confirm Password"
            type="password"
            value={profileData.confirmPassword}
            onChange={(value) => setProfileData(prev => ({ ...prev, confirmPassword: value }))}
            placeholder="Confirm new password"
          />
        </div>
      </Card>

      <div className="flex justify-end">
        <Button onClick={handleProfileUpdate}>
          <i className="bi bi-check-lg mr-2"></i>
          Update Profile
        </Button>
      </div>
    </div>
  );

  const renderSystemSettings = () => (
    <div className="space-y-6">
      <Card>
        <h3 className="text-lg font-semibold text-secondary-900 mb-4">Company Settings</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input
            label="Company Name"
            value={systemSettings.companyName}
            onChange={(value) => setSystemSettings(prev => ({ ...prev, companyName: value }))}
            placeholder="Enter company name"
          />
          <Select
            label="Timezone"
            value={systemSettings.timezone}
            onChange={(value) => setSystemSettings(prev => ({ ...prev, timezone: value }))}
            options={[
              { value: 'UTC', label: 'UTC' },
              { value: 'EST', label: 'Eastern Time' },
              { value: 'PST', label: 'Pacific Time' },
              { value: 'CST', label: 'Central Time' },
            ]}
          />
          <Select
            label="Date Format"
            value={systemSettings.dateFormat}
            onChange={(value) => setSystemSettings(prev => ({ ...prev, dateFormat: value }))}
            options={[
              { value: 'MM/DD/YYYY', label: 'MM/DD/YYYY' },
              { value: 'DD/MM/YYYY', label: 'DD/MM/YYYY' },
              { value: 'YYYY-MM-DD', label: 'YYYY-MM-DD' },
            ]}
          />
          <Select
            label="Currency"
            value={systemSettings.currency}
            onChange={(value) => setSystemSettings(prev => ({ ...prev, currency: value }))}
            options={[
              { value: 'USD', label: 'US Dollar (USD)' },
              { value: 'EUR', label: 'Euro (EUR)' },
              { value: 'GBP', label: 'British Pound (GBP)' },
              { value: 'INR', label: 'Indian Rupee (INR)' },
            ]}
          />
        </div>
      </Card>

      <Card>
        <h3 className="text-lg font-semibold text-secondary-900 mb-4">Lead Management</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              id="autoAssignLeads"
              checked={systemSettings.autoAssignLeads}
              onChange={(e) => setSystemSettings(prev => ({ ...prev, autoAssignLeads: e.target.checked }))}
              className="rounded border-secondary-300 text-primary-600 focus:ring-primary-500"
            />
            <label htmlFor="autoAssignLeads" className="text-sm font-medium text-secondary-700">
              Auto-assign leads
            </label>
          </div>
          <Input
            label="Lead Retention (Days)"
            type="number"
            value={systemSettings.leadRetentionDays}
            onChange={(value) => setSystemSettings(prev => ({ ...prev, leadRetentionDays: value }))}
            placeholder="365"
          />
          <Input
            label="Max Users per Manager"
            type="number"
            value={systemSettings.maxUsersPerManager}
            onChange={(value) => setSystemSettings(prev => ({ ...prev, maxUsersPerManager: value }))}
            placeholder="10"
          />
        </div>
      </Card>

      <div className="flex justify-end">
        <Button onClick={handleSystemSettingsUpdate}>
          <i className="bi bi-check-lg mr-2"></i>
          Update Settings
        </Button>
      </div>
    </div>
  );

  const renderSecuritySettings = () => (
    <div className="space-y-6">
      <Card>
        <h3 className="text-lg font-semibold text-secondary-900 mb-4">Password Policy</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input
            label="Minimum Password Length"
            type="number"
            value={securitySettings.passwordMinLength}
            onChange={(value) => setSecuritySettings(prev => ({ ...prev, passwordMinLength: value }))}
            placeholder="8"
          />
          <div className="flex items-center space-x-2 mt-6">
            <input
              type="checkbox"
              id="requireSpecialChars"
              checked={securitySettings.requireSpecialChars}
              onChange={(e) => setSecuritySettings(prev => ({ ...prev, requireSpecialChars: e.target.checked }))}
              className="rounded border-secondary-300 text-primary-600 focus:ring-primary-500"
            />
            <label htmlFor="requireSpecialChars" className="text-sm font-medium text-secondary-700">
              Require special characters
            </label>
          </div>
        </div>
      </Card>

      <Card>
        <h3 className="text-lg font-semibold text-secondary-900 mb-4">Session & Access Control</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Input
            label="Session Timeout (Minutes)"
            type="number"
            value={securitySettings.sessionTimeout}
            onChange={(value) => setSecuritySettings(prev => ({ ...prev, sessionTimeout: value }))}
            placeholder="60"
          />
          <Input
            label="Max Login Attempts"
            type="number"
            value={securitySettings.loginAttempts}
            onChange={(value) => setSecuritySettings(prev => ({ ...prev, loginAttempts: value }))}
            placeholder="5"
          />
          <Input
            label="Account Lockout Time (Minutes)"
            type="number"
            value={securitySettings.accountLockoutTime}
            onChange={(value) => setSecuritySettings(prev => ({ ...prev, accountLockoutTime: value }))}
            placeholder="30"
          />
        </div>
        <div className="mt-4">
          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              id="twoFactorAuth"
              checked={securitySettings.twoFactorAuth}
              onChange={(e) => setSecuritySettings(prev => ({ ...prev, twoFactorAuth: e.target.checked }))}
              className="rounded border-secondary-300 text-primary-600 focus:ring-primary-500"
            />
            <label htmlFor="twoFactorAuth" className="text-sm font-medium text-secondary-700">
              Enable Two-Factor Authentication
            </label>
          </div>
        </div>
      </Card>

      <div className="flex justify-end">
        <Button onClick={handleSecuritySettingsUpdate}>
          <i className="bi bi-check-lg mr-2"></i>
          Update Security Settings
        </Button>
      </div>
    </div>
  );

  const renderNotificationSettings = () => (
    <div className="space-y-6">
      <Card>
        <h3 className="text-lg font-semibold text-secondary-900 mb-4">Notification Preferences</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-secondary-50 rounded-lg">
            <div>
              <h4 className="font-medium text-secondary-900">Email Notifications</h4>
              <p className="text-sm text-secondary-600">Receive notifications via email</p>
            </div>
            <input
              type="checkbox"
              checked={systemSettings.emailNotifications}
              onChange={(e) => setSystemSettings(prev => ({ ...prev, emailNotifications: e.target.checked }))}
              className="rounded border-secondary-300 text-primary-600 focus:ring-primary-500"
            />
          </div>
          
          <div className="flex items-center justify-between p-4 bg-secondary-50 rounded-lg">
            <div>
              <h4 className="font-medium text-secondary-900">SMS Notifications</h4>
              <p className="text-sm text-secondary-600">Receive notifications via SMS</p>
            </div>
            <input
              type="checkbox"
              checked={systemSettings.smsNotifications}
              onChange={(e) => setSystemSettings(prev => ({ ...prev, smsNotifications: e.target.checked }))}
              className="rounded border-secondary-300 text-primary-600 focus:ring-primary-500"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
            <div className="space-y-2">
              <h4 className="font-medium text-secondary-900">Lead Notifications</h4>
              <label className="flex items-center space-x-2">
                <input type="checkbox" defaultChecked className="rounded border-secondary-300 text-primary-600 focus:ring-primary-500" />
                <span className="text-sm text-secondary-700">New lead assigned</span>
              </label>
              <label className="flex items-center space-x-2">
                <input type="checkbox" defaultChecked className="rounded border-secondary-300 text-primary-600 focus:ring-primary-500" />
                <span className="text-sm text-secondary-700">Lead status changed</span>
              </label>
              <label className="flex items-center space-x-2">
                <input type="checkbox" className="rounded border-secondary-300 text-primary-600 focus:ring-primary-500" />
                <span className="text-sm text-secondary-700">Lead follow-up reminders</span>
              </label>
            </div>

            <div className="space-y-2">
              <h4 className="font-medium text-secondary-900">System Notifications</h4>
              <label className="flex items-center space-x-2">
                <input type="checkbox" defaultChecked className="rounded border-secondary-300 text-primary-600 focus:ring-primary-500" />
                <span className="text-sm text-secondary-700">User login alerts</span>
              </label>
              <label className="flex items-center space-x-2">
                <input type="checkbox" className="rounded border-secondary-300 text-primary-600 focus:ring-primary-500" />
                <span className="text-sm text-secondary-700">System maintenance</span>
              </label>
              <label className="flex items-center space-x-2">
                <input type="checkbox" defaultChecked className="rounded border-secondary-300 text-primary-600 focus:ring-primary-500" />
                <span className="text-sm text-secondary-700">Data backup completed</span>
              </label>
            </div>
          </div>
        </div>
      </Card>

      <div className="flex justify-end">
        <Button onClick={() => toast.success('Notification settings updated')}>
          <i className="bi bi-check-lg mr-2"></i>
          Update Notifications
        </Button>
      </div>
    </div>
  );

  const renderDataManagement = () => (
    <div className="space-y-6">
      <Card>
        <h3 className="text-lg font-semibold text-secondary-900 mb-4">Data Backup & Restore</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="text-center p-6 border-2 border-dashed border-secondary-300 rounded-lg">
            <i className="bi bi-download text-4xl text-primary-600 mb-4"></i>
            <h4 className="font-medium text-secondary-900 mb-2">Backup Data</h4>
            <p className="text-sm text-secondary-600 mb-4">Download a complete backup of your CRM data</p>
            <Button onClick={() => setShowBackupModal(true)}>
              Create Backup
            </Button>
          </div>

          <div className="text-center p-6 border-2 border-dashed border-secondary-300 rounded-lg">
            <i className="bi bi-upload text-4xl text-green-600 mb-4"></i>
            <h4 className="font-medium text-secondary-900 mb-2">Restore Data</h4>
            <p className="text-sm text-secondary-600 mb-4">Restore your CRM data from a backup file</p>
            <Button variant="success" onClick={() => setShowRestoreModal(true)}>
              Restore Backup
            </Button>
          </div>
        </div>
      </Card>

      <Card>
        <h3 className="text-lg font-semibold text-secondary-900 mb-4">Data Statistics</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="text-center p-4 bg-blue-50 rounded-lg">
            <div className="text-2xl font-bold text-blue-600">{users.length}</div>
            <div className="text-sm text-blue-800">Total Users</div>
          </div>
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <div className="text-2xl font-bold text-green-600">{leads.length}</div>
            <div className="text-sm text-green-800">Total Leads</div>
          </div>
          <div className="text-center p-4 bg-purple-50 rounded-lg">
            <div className="text-2xl font-bold text-purple-600">{leads.filter(l => l.stage === 'closed-won').length}</div>
            <div className="text-sm text-purple-800">Closed Won</div>
          </div>
          <div className="text-center p-4 bg-yellow-50 rounded-lg">
            <div className="text-2xl font-bold text-yellow-600">{Math.round((new Date().getTime() - new Date('2024-01-01').getTime()) / (1000 * 60 * 60 * 24))}</div>
            <div className="text-sm text-yellow-800">Days Active</div>
          </div>
        </div>
      </Card>

      <Card>
        <h3 className="text-lg font-semibold text-secondary-900 mb-4">Danger Zone</h3>
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
          <h4 className="font-medium text-red-900 mb-2">Clear All Data</h4>
          <p className="text-sm text-red-700 mb-4">
            This will permanently delete all users, leads, and settings. This action cannot be undone.
          </p>
          <Button variant="danger" onClick={clearAllData}>
            <i className="bi bi-exclamation-triangle mr-2"></i>
            Clear All Data
          </Button>
        </div>
      </Card>
    </div>
  );

  const renderIntegrations = () => (
    <div className="space-y-6">
      <Card>
        <h3 className="text-lg font-semibold text-secondary-900 mb-4">Available Integrations</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            { name: 'Slack', icon: 'bi-slack', description: 'Get notifications in Slack', status: 'Available' },
            { name: 'Microsoft Teams', icon: 'bi-microsoft-teams', description: 'Collaborate with your team', status: 'Available' },
            { name: 'Google Workspace', icon: 'bi-google', description: 'Sync with Google Calendar', status: 'Coming Soon' },
            { name: 'Zapier', icon: 'bi-lightning', description: 'Connect with 3000+ apps', status: 'Available' },
            { name: 'Mailchimp', icon: 'bi-envelope', description: 'Email marketing automation', status: 'Coming Soon' },
            { name: 'Salesforce', icon: 'bi-cloud', description: 'Import/export data', status: 'Coming Soon' },
          ].map((integration, index) => (
            <div key={index} className="p-4 border border-secondary-200 rounded-lg hover:shadow-md transition-shadow duration-200">
              <div className="flex items-center space-x-3 mb-3">
                <i className={`${integration.icon} text-2xl text-primary-600`}></i>
                <div>
                  <h4 className="font-medium text-secondary-900">{integration.name}</h4>
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    integration.status === 'Available' 
                      ? 'bg-green-100 text-green-800' 
                      : 'bg-yellow-100 text-yellow-800'
                  }`}>
                    {integration.status}
                  </span>
                </div>
              </div>
              <p className="text-sm text-secondary-600 mb-3">{integration.description}</p>
              <Button 
                size="sm" 
                variant={integration.status === 'Available' ? 'primary' : 'secondary'}
                disabled={integration.status !== 'Available'}
                className="w-full"
              >
                {integration.status === 'Available' ? 'Connect' : 'Coming Soon'}
              </Button>
            </div>
          ))}
        </div>
      </Card>

      <Card>
        <h3 className="text-lg font-semibold text-secondary-900 mb-4">API Settings</h3>
        <div className="space-y-4">
          <div className="p-4 bg-secondary-50 rounded-lg">
            <h4 className="font-medium text-secondary-900 mb-2">API Key</h4>
            <div className="flex items-center space-x-2">
              <Input
                value="sk_live_xxxxxxxxxxxxxxxxxxxxxxxx"
                onChange={() => {}}
                disabled
                className="flex-1"
              />
              <Button variant="secondary" size="sm">
                <i className="bi bi-copy mr-2"></i>
                Copy
              </Button>
              <Button variant="secondary" size="sm">
                <i className="bi bi-arrow-clockwise mr-2"></i>
                Regenerate
              </Button>
            </div>
          </div>
          
          <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <h4 className="font-medium text-blue-900 mb-2">API Documentation</h4>
            <p className="text-sm text-blue-800 mb-3">
              Learn how to integrate with our REST API to build custom applications.
            </p>
            <Button variant="secondary" size="sm">
              <i className="bi bi-book mr-2"></i>
              View Documentation
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );

  const renderContent = () => {
    switch (activeSection) {
      case 'profile':
        return renderProfileSettings();
      case 'system':
        return renderSystemSettings();
      case 'security':
        return renderSecuritySettings();
      case 'notifications':
        return renderNotificationSettings();
      case 'data':
        return renderDataManagement();
      case 'integrations':
        return renderIntegrations();
      default:
        return renderProfileSettings();
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-secondary-900">Settings</h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Settings Menu */}
        <Card className="lg:col-span-1">
          <nav className="space-y-2">
            {filteredMenuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveSection(item.id)}
                className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg transition-all duration-200 text-left ${
                  activeSection === item.id
                    ? 'bg-primary-100 text-primary-700 border-l-4 border-primary-600'
                    : 'text-secondary-600 hover:bg-secondary-100 hover:text-secondary-900'
                }`}
              >
                <i className={`${item.icon} text-lg`}></i>
                <span className="font-medium">{item.label}</span>
              </button>
            ))}
          </nav>
        </Card>

        {/* Settings Content */}
        <div className="lg:col-span-3">
          {renderContent()}
        </div>
      </div>

      {/* Backup Modal */}
      <Modal
        isOpen={showBackupModal}
        onClose={() => setShowBackupModal(false)}
        title="Create Data Backup"
        size="md"
      >
        <div className="text-center space-y-4">
          <i className="bi bi-download text-4xl text-primary-600"></i>
          <p className="text-secondary-700">
            This will create a complete backup of all your CRM data including users, leads, and settings.
          </p>
          <div className="flex justify-center space-x-3">
            <Button variant="secondary" onClick={() => setShowBackupModal(false)}>
              Cancel
            </Button>
            <Button onClick={handleBackupData}>
              <i className="bi bi-download mr-2"></i>
              Create Backup
            </Button>
          </div>
        </div>
      </Modal>

      {/* Restore Modal */}
      <Modal
        isOpen={showRestoreModal}
        onClose={() => setShowRestoreModal(false)}
        title="Restore Data Backup"
        size="md"
      >
        <div className="text-center space-y-4">
          <i className="bi bi-upload text-4xl text-green-600"></i>
          <p className="text-secondary-700">
            Select a backup file to restore your CRM data. This will overwrite existing data.
          </p>
          <div className="border-2 border-dashed border-secondary-300 rounded-lg p-6">
            <input
              type="file"
              accept=".json"
              onChange={handleRestoreData}
              className="hidden"
              id="restore-file"
            />
            <label
              htmlFor="restore-file"
              className="cursor-pointer flex flex-col items-center space-y-2"
            >
              <i className="bi bi-cloud-upload text-3xl text-secondary-400"></i>
              <span className="text-secondary-600">Click to select backup file</span>
            </label>
          </div>
          <div className="flex justify-center space-x-3">
            <Button variant="secondary" onClick={() => setShowRestoreModal(false)}>
              Cancel
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default Settings;
