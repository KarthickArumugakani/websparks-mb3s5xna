import React from 'react';
import Card from '../common/Card';

interface StatsCardProps {
  title: string;
  value: string | number;
  icon: string;
  trend?: {
    value: number;
    isPositive: boolean;
  };
  color?: 'blue' | 'green' | 'yellow' | 'red' | 'purple';
}

const StatsCard: React.FC<StatsCardProps> = ({
  title,
  value,
  icon,
  trend,
  color = 'blue',
}) => {
  const colorClasses = {
    blue: 'bg-blue-500 text-blue-600',
    green: 'bg-green-500 text-green-600',
    yellow: 'bg-yellow-500 text-yellow-600',
    red: 'bg-red-500 text-red-600',
    purple: 'bg-purple-500 text-purple-600',
  };

  return (
    <Card hover className="animate-fade-in">
      <div className="flex items-center justify-between">
        <div className="flex-1">
          <p className="text-sm font-medium text-secondary-600 mb-1">{title}</p>
          <p className="text-2xl font-bold text-secondary-900">{value}</p>
          {trend && (
            <div className="flex items-center mt-2">
              <i className={`bi ${trend.isPositive ? 'bi-arrow-up' : 'bi-arrow-down'} text-sm mr-1 ${
                trend.isPositive ? 'text-green-600' : 'text-red-600'
              }`}></i>
              <span className={`text-sm font-medium ${
                trend.isPositive ? 'text-green-600' : 'text-red-600'
              }`}>
                {Math.abs(trend.value)}%
              </span>
              <span className="text-sm text-secondary-500 ml-1">vs last month</span>
            </div>
          )}
        </div>
        <div className={`w-12 h-12 rounded-lg ${colorClasses[color].split(' ')[0]} bg-opacity-10 flex items-center justify-center`}>
          <i className={`${icon} text-xl ${colorClasses[color].split(' ')[1]}`}></i>
        </div>
      </div>
    </Card>
  );
};

export default StatsCard;
