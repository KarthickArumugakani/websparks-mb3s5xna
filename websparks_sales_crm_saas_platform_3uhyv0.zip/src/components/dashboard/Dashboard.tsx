import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import StatsCard from './StatsCard';
import Card from '../common/Card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const { leads, users } = useData();

  // Calculate stats based on user role
  const getFilteredLeads = () => {
    if (user?.role === 'user') {
      return leads.filter(lead => lead.assignedTo === user.id);
    }
    if (user?.role === 'manager') {
      const teamMembers = users.filter(u => u.managerId === user.id);
      const teamIds = [user.id, ...teamMembers.map(u => u.id)];
      return leads.filter(lead => teamIds.includes(lead.assignedTo));
    }
    return leads;
  };

  const filteredLeads = getFilteredLeads();
  const hotLeads = filteredLeads.filter(lead => lead.status === 'hot').length;
  const closedWon = filteredLeads.filter(lead => lead.stage === 'closed-won').length;
  const conversionRate = filteredLeads.length > 0 ? Math.round((closedWon / filteredLeads.length) * 100) : 0;

  const teamMembers = user?.role === 'user' ? 1 : 
    user?.role === 'manager' ? users.filter(u => u.managerId === user.id).length + 1 :
    users.length;

  // Chart data
  const monthlyData = [
    { month: 'Jan', leads: 45, closed: 12 },
    { month: 'Feb', leads: 52, closed: 15 },
    { month: 'Mar', leads: 48, closed: 18 },
    { month: 'Apr', leads: 61, closed: 22 },
    { month: 'May', leads: 55, closed: 19 },
    { month: 'Jun', leads: 67, closed: 25 },
  ];

  const statusData = [
    { name: 'Hot', value: filteredLeads.filter(l => l.status === 'hot').length, color: '#ef4444' },
    { name: 'Warm', value: filteredLeads.filter(l => l.status === 'warm').length, color: '#f59e0b' },
    { name: 'Cold', value: filteredLeads.filter(l => l.status === 'cold').length, color: '#3b82f6' },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-secondary-900">
          Welcome back, {user?.name}!
        </h2>
        <div className="text-sm text-secondary-500">
          {new Date().toLocaleDateString('en-US', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          })}
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard
          title="Total Leads"
          value={filteredLeads.length}
          icon="bi-person-lines-fill"
          trend={{ value: 12, isPositive: true }}
          color="blue"
        />
        <StatsCard
          title="Hot Leads"
          value={hotLeads}
          icon="bi-fire"
          trend={{ value: 8, isPositive: true }}
          color="red"
        />
        <StatsCard
          title="Closed Won"
          value={closedWon}
          icon="bi-trophy"
          trend={{ value: 15, isPositive: true }}
          color="green"
        />
        <StatsCard
          title="Conversion Rate"
          value={`${conversionRate}%`}
          icon="bi-graph-up"
          trend={{ value: 3, isPositive: true }}
          color="purple"
        />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <h3 className="text-lg font-semibold text-secondary-900 mb-4">Monthly Performance</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={monthlyData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="leads" fill="#3b82f6" name="Total Leads" />
              <Bar dataKey="closed" fill="#10b981" name="Closed Won" />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <Card>
          <h3 className="text-lg font-semibold text-secondary-900 mb-4">Lead Status Distribution</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={statusData}
                cx="50%"
                cy="50%"
                outerRadius={80}
                dataKey="value"
                label={({ name, value }) => `${name}: ${value}`}
              >
                {statusData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card>
        <h3 className="text-lg font-semibold text-secondary-900 mb-4">Recent Activity</h3>
        <div className="space-y-4">
          {filteredLeads.slice(0, 5).map((lead) => (
            <div key={lead.id} className="flex items-center space-x-4 p-3 bg-secondary-50 rounded-lg">
              <div className={`w-3 h-3 rounded-full ${
                lead.status === 'hot' ? 'bg-red-500' :
                lead.status === 'warm' ? 'bg-yellow-500' : 'bg-blue-500'
              }`}></div>
              <div className="flex-1">
                <p className="font-medium text-secondary-900">{lead.name}</p>
                <p className="text-sm text-secondary-600">
                  Stage: {lead.stage.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                </p>
              </div>
              <div className="text-sm text-secondary-500">
                {new Date(lead.updatedAt).toLocaleDateString()}
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};

export default Dashboard;
