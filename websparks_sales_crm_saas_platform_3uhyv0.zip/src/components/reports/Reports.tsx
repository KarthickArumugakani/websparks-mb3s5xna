import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import Card from '../common/Card';
import Button from '../common/Button';
import Select from '../common/Select';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell, AreaChart, Area } from 'recharts';

const Reports: React.FC = () => {
  const { user } = useAuth();
  const { leads, users } = useData();
  const [reportType, setReportType] = useState('overview');
  const [dateRange, setDateRange] = useState('30');
  const [selectedUser, setSelectedUser] = useState('');

  // Filter data based on user role and date range
  const getFilteredData = () => {
    let filteredLeads = leads;
    let filteredUsers = users;

    // Role-based filtering
    if (user?.role === 'user') {
      filteredLeads = leads.filter(lead => lead.assignedTo === user.id);
      filteredUsers = users.filter(u => u.id === user.id);
    } else if (user?.role === 'manager') {
      const teamMembers = users.filter(u => u.managerId === user.id);
      const teamIds = [user.id, ...teamMembers.map(u => u.id)];
      filteredLeads = leads.filter(lead => teamIds.includes(lead.assignedTo));
      filteredUsers = users.filter(u => teamIds.includes(u.id));
    }

    // Date range filtering
    const daysAgo = parseInt(dateRange);
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - daysAgo);
    
    filteredLeads = filteredLeads.filter(lead => 
      new Date(lead.createdAt) >= cutoffDate
    );

    // User-specific filtering
    if (selectedUser) {
      filteredLeads = filteredLeads.filter(lead => lead.assignedTo === selectedUser);
    }

    return { filteredLeads, filteredUsers };
  };

  const { filteredLeads, filteredUsers } = getFilteredData();

  // Generate report data
  const generateOverviewData = () => {
    const totalLeads = filteredLeads.length;
    const hotLeads = filteredLeads.filter(l => l.status === 'hot').length;
    const warmLeads = filteredLeads.filter(l => l.status === 'warm').length;
    const coldLeads = filteredLeads.filter(l => l.status === 'cold').length;
    const closedWon = filteredLeads.filter(l => l.stage === 'closed-won').length;
    const closedLost = filteredLeads.filter(l => l.stage === 'closed-lost').length;
    const totalValue = filteredLeads.reduce((sum, lead) => sum + (lead.value || 0), 0);
    const wonValue = filteredLeads.filter(l => l.stage === 'closed-won').reduce((sum, lead) => sum + (lead.value || 0), 0);

    return {
      totalLeads,
      hotLeads,
      warmLeads,
      coldLeads,
      closedWon,
      closedLost,
      conversionRate: totalLeads > 0 ? Math.round((closedWon / totalLeads) * 100) : 0,
      totalValue,
      wonValue,
      avgDealSize: closedWon > 0 ? Math.round(wonValue / closedWon) : 0
    };
  };

  const generatePerformanceData = () => {
    const userPerformance = filteredUsers.map(u => {
      const userLeads = filteredLeads.filter(l => l.assignedTo === u.id);
      const closedWon = userLeads.filter(l => l.stage === 'closed-won').length;
      const totalValue = userLeads.reduce((sum, lead) => sum + (lead.value || 0), 0);
      
      return {
        name: u.name,
        totalLeads: userLeads.length,
        closedWon,
        conversionRate: userLeads.length > 0 ? Math.round((closedWon / userLeads.length) * 100) : 0,
        totalValue,
        role: u.role
      };
    });

    return userPerformance.sort((a, b) => b.totalValue - a.totalValue);
  };

  const generateTrendData = () => {
    const last30Days = Array.from({ length: 30 }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - (29 - i));
      return date.toISOString().split('T')[0];
    });

    return last30Days.map(date => {
      const dayLeads = filteredLeads.filter(l => l.createdAt.split('T')[0] === date);
      const dayClosedWon = dayLeads.filter(l => l.stage === 'closed-won');
      
      return {
        date: new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        leads: dayLeads.length,
        closedWon: dayClosedWon.length,
        value: dayClosedWon.reduce((sum, lead) => sum + (lead.value || 0), 0)
      };
    });
  };

  const generatePipelineData = () => {
    const stages = ['initial', 'negotiation', 'follow-up', 'closed-won', 'closed-lost'];
    
    return stages.map(stage => {
      const stageLeads = filteredLeads.filter(l => l.stage === stage);
      const stageValue = stageLeads.reduce((sum, lead) => sum + (lead.value || 0), 0);
      
      return {
        stage: stage.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase()),
        count: stageLeads.length,
        value: stageValue,
        percentage: filteredLeads.length > 0 ? Math.round((stageLeads.length / filteredLeads.length) * 100) : 0
      };
    });
  };

  const overviewData = generateOverviewData();
  const performanceData = generatePerformanceData();
  const trendData = generateTrendData();
  const pipelineData = generatePipelineData();

  const statusData = [
    { name: 'Hot', value: overviewData.hotLeads, color: '#ef4444' },
    { name: 'Warm', value: overviewData.warmLeads, color: '#f59e0b' },
    { name: 'Cold', value: overviewData.coldLeads, color: '#3b82f6' },
  ];

  const reportTypeOptions = [
    { value: 'overview', label: 'Overview Report' },
    { value: 'performance', label: 'Team Performance' },
    { value: 'trends', label: 'Trends Analysis' },
    { value: 'pipeline', label: 'Sales Pipeline' },
  ];

  const dateRangeOptions = [
    { value: '7', label: 'Last 7 days' },
    { value: '30', label: 'Last 30 days' },
    { value: '90', label: 'Last 90 days' },
    { value: '365', label: 'Last year' },
  ];

  const userOptions = [
    { value: '', label: 'All Users' },
    ...filteredUsers.map(u => ({ value: u.id, label: u.name }))
  ];

  const exportReport = () => {
    const reportData = {
      reportType,
      dateRange,
      generatedAt: new Date().toISOString(),
      overview: overviewData,
      performance: performanceData,
      trends: trendData,
      pipeline: pipelineData
    };

    const dataStr = JSON.stringify(reportData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `sales-report-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const renderOverviewReport = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <div className="text-center">
            <div className="text-3xl font-bold text-primary-600 mb-2">{overviewData.totalLeads}</div>
            <div className="text-sm text-secondary-600">Total Leads</div>
          </div>
        </Card>
        <Card>
          <div className="text-center">
            <div className="text-3xl font-bold text-green-600 mb-2">{overviewData.closedWon}</div>
            <div className="text-sm text-secondary-600">Closed Won</div>
          </div>
        </Card>
        <Card>
          <div className="text-center">
            <div className="text-3xl font-bold text-purple-600 mb-2">{overviewData.conversionRate}%</div>
            <div className="text-sm text-secondary-600">Conversion Rate</div>
          </div>
        </Card>
        <Card>
          <div className="text-center">
            <div className="text-3xl font-bold text-blue-600 mb-2">${overviewData.wonValue.toLocaleString()}</div>
            <div className="text-sm text-secondary-600">Revenue Won</div>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <h3 className="text-lg font-semibold text-secondary-900 mb-4">Lead Status Distribution</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={statusData}
                cx="50%"
                cy="50%"
                outerRadius={80}
                dataKey="value"
                label={({ name, value }) => `${name}: ${value}`}
              >
                {statusData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </Card>

        <Card>
          <h3 className="text-lg font-semibold text-secondary-900 mb-4">Sales Pipeline</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={pipelineData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="stage" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="count" fill="#3b82f6" />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>
    </div>
  );

  const renderPerformanceReport = () => (
    <div className="space-y-6">
      <Card>
        <h3 className="text-lg font-semibold text-secondary-900 mb-4">Team Performance</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-secondary-200">
                <th className="text-left py-3 px-4 font-semibold text-secondary-900">User</th>
                <th className="text-left py-3 px-4 font-semibold text-secondary-900">Role</th>
                <th className="text-left py-3 px-4 font-semibold text-secondary-900">Total Leads</th>
                <th className="text-left py-3 px-4 font-semibold text-secondary-900">Closed Won</th>
                <th className="text-left py-3 px-4 font-semibold text-secondary-900">Conversion Rate</th>
                <th className="text-left py-3 px-4 font-semibold text-secondary-900">Total Value</th>
              </tr>
            </thead>
            <tbody>
              {performanceData.map((user, index) => (
                <tr key={index} className="border-b border-secondary-100">
                  <td className="py-3 px-4 font-medium text-secondary-900">{user.name}</td>
                  <td className="py-3 px-4 text-secondary-600 capitalize">{user.role}</td>
                  <td className="py-3 px-4 text-secondary-900">{user.totalLeads}</td>
                  <td className="py-3 px-4 text-green-600 font-medium">{user.closedWon}</td>
                  <td className="py-3 px-4 text-secondary-900">{user.conversionRate}%</td>
                  <td className="py-3 px-4 text-blue-600 font-medium">${user.totalValue.toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <Card>
        <h3 className="text-lg font-semibold text-secondary-900 mb-4">Performance Comparison</h3>
        <ResponsiveContainer width="100%" height={400}>
          <BarChart data={performanceData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="totalLeads" fill="#3b82f6" name="Total Leads" />
            <Bar dataKey="closedWon" fill="#10b981" name="Closed Won" />
          </BarChart>
        </ResponsiveContainer>
      </Card>
    </div>
  );

  const renderTrendsReport = () => (
    <div className="space-y-6">
      <Card>
        <h3 className="text-lg font-semibold text-secondary-900 mb-4">Lead Generation Trends</h3>
        <ResponsiveContainer width="100%" height={400}>
          <LineChart data={trendData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip />
            <Line type="monotone" dataKey="leads" stroke="#3b82f6" strokeWidth={2} name="New Leads" />
            <Line type="monotone" dataKey="closedWon" stroke="#10b981" strokeWidth={2} name="Closed Won" />
          </LineChart>
        </ResponsiveContainer>
      </Card>

      <Card>
        <h3 className="text-lg font-semibold text-secondary-900 mb-4">Revenue Trends</h3>
        <ResponsiveContainer width="100%" height={400}>
          <AreaChart data={trendData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip formatter={(value) => [`$${value.toLocaleString()}`, 'Revenue']} />
            <Area type="monotone" dataKey="value" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.3} />
          </AreaChart>
        </ResponsiveContainer>
      </Card>
    </div>
  );

  const renderPipelineReport = () => (
    <div className="space-y-6">
      <Card>
        <h3 className="text-lg font-semibold text-secondary-900 mb-4">Sales Pipeline Analysis</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
          {pipelineData.map((stage, index) => (
            <Card key={index} className="text-center">
              <div className="text-2xl font-bold text-primary-600 mb-2">{stage.count}</div>
              <div className="text-sm text-secondary-600 mb-1">{stage.stage}</div>
              <div className="text-xs text-secondary-500">${stage.value.toLocaleString()}</div>
              <div className="text-xs text-secondary-500">{stage.percentage}%</div>
            </Card>
          ))}
        </div>
        
        <ResponsiveContainer width="100%" height={400}>
          <BarChart data={pipelineData} layout="horizontal">
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis type="number" />
            <YAxis dataKey="stage" type="category" width={100} />
            <Tooltip formatter={(value, name) => [
              name === 'value' ? `$${value.toLocaleString()}` : value,
              name === 'value' ? 'Total Value' : 'Lead Count'
            ]} />
            <Bar dataKey="count" fill="#3b82f6" name="count" />
          </BarChart>
        </ResponsiveContainer>
      </Card>
    </div>
  );

  const renderReport = () => {
    switch (reportType) {
      case 'overview':
        return renderOverviewReport();
      case 'performance':
        return renderPerformanceReport();
      case 'trends':
        return renderTrendsReport();
      case 'pipeline':
        return renderPipelineReport();
      default:
        return renderOverviewReport();
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-secondary-900">Reports & Analytics</h2>
        <Button onClick={exportReport}>
          <i className="bi bi-download mr-2"></i>
          Export Report
        </Button>
      </div>

      {/* Report Controls */}
      <Card>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Select
            label="Report Type"
            value={reportType}
            onChange={setReportType}
            options={reportTypeOptions}
          />
          <Select
            label="Date Range"
            value={dateRange}
            onChange={setDateRange}
            options={dateRangeOptions}
          />
          {(user?.role === 'owner' || user?.role === 'admin' || user?.role === 'manager') && (
            <Select
              label="Filter by User"
              value={selectedUser}
              onChange={setSelectedUser}
              options={userOptions}
            />
          )}
          <div className="flex items-end">
            <Button
              variant="secondary"
              onClick={() => {
                setReportType('overview');
                setDateRange('30');
                setSelectedUser('');
              }}
              className="w-full"
            >
              <i className="bi bi-arrow-clockwise mr-2"></i>
              Reset Filters
            </Button>
          </div>
        </div>
      </Card>

      {/* Report Content */}
      {renderReport()}
    </div>
  );
};

export default Reports;
