import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import Button from '../common/Button';
import Input from '../common/Input';
import Card from '../common/Card';
import toast from 'react-hot-toast';

const LoginForm: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { login, isLoading } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !password) {
      toast.error('Please fill in all fields');
      return;
    }

    const success = await login(email, password);
    if (!success) {
      toast.error('Invalid credentials');
    }
  };

  const demoCredentials = [
    { role: 'Owner', email: 'owner@company.com', password: 'password123' },
    { role: 'Admin', email: 'admin@company.com', password: 'password123' },
    { role: 'Manager', email: 'manager@company.com', password: 'password123' },
    { role: 'User', email: 'user@company.com', password: 'password123' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 to-secondary-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-primary-600 rounded-2xl flex items-center justify-center mx-auto mb-4 animate-bounce-subtle">
            <i className="bi bi-graph-up text-white text-2xl"></i>
          </div>
          <h1 className="text-3xl font-bold text-secondary-900 mb-2">SalesPro CRM</h1>
          <p className="text-secondary-600">Sign in to your account</p>
        </div>

        <Card className="animate-fade-in">
          <form onSubmit={handleSubmit}>
            <Input
              label="Email Address"
              type="email"
              value={email}
              onChange={setEmail}
              placeholder="Enter your email"
              required
            />

            <Input
              label="Password"
              type="password"
              value={password}
              onChange={setPassword}
              placeholder="Enter your password"
              required
            />

            <Button
              type="submit"
              className="w-full"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <i className="bi bi-arrow-clockwise animate-spin mr-2"></i>
                  Signing in...
                </>
              ) : (
                'Sign In'
              )}
            </Button>
          </form>

          <div className="mt-6 pt-6 border-t border-secondary-200">
            <h3 className="text-sm font-medium text-secondary-700 mb-3">Demo Credentials:</h3>
            <div className="space-y-2">
              {demoCredentials.map((cred, index) => (
                <div key={index} className="flex justify-between items-center text-xs">
                  <span className="font-medium text-secondary-600">{cred.role}:</span>
                  <button
                    type="button"
                    onClick={() => {
                      setEmail(cred.email);
                      setPassword(cred.password);
                    }}
                    className="text-primary-600 hover:text-primary-700 underline"
                  >
                    {cred.email}
                  </button>
                </div>
              ))}
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default LoginForm;
