import React from 'react';
import { useAuth } from '../../context/AuthContext';
import Button from '../common/Button';

const Header: React.FC = () => {
  const { user, logout } = useAuth();

  return (
    <header className="bg-white border-b border-secondary-200 px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <h1 className="text-2xl font-bold text-secondary-900">
            Sales CRM Dashboard
          </h1>
        </div>

        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <i className="bi bi-bell text-secondary-600 text-lg"></i>
            <span className="bg-red-500 text-white text-xs rounded-full px-2 py-1">3</span>
          </div>
          
          <div className="flex items-center space-x-3">
            <div className="text-right">
              <p className="text-sm font-medium text-secondary-900">{user?.name}</p>
              <p className="text-xs text-secondary-500 capitalize">{user?.role}</p>
            </div>
            <div className="w-8 h-8 bg-primary-600 rounded-full flex items-center justify-center">
              <span className="text-white text-sm font-medium">
                {user?.name.charAt(0).toUpperCase()}
              </span>
            </div>
          </div>

          <Button variant="secondary" size="sm" onClick={logout}>
            <i className="bi bi-box-arrow-right mr-2"></i>
            Logout
          </Button>
        </div>
      </div>
    </header>
  );
};

export default Header;
