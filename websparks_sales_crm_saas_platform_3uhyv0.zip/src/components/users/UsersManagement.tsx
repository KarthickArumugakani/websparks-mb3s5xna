import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { User } from '../../types';
import Button from '../common/Button';
import Card from '../common/Card';
import Modal from '../common/Modal';
import Input from '../common/Input';
import Select from '../common/Select';
import UserForm from './UserForm';
import BulkUpload from '../leads/BulkUpload';
import toast from 'react-hot-toast';

const UsersManagement: React.FC = () => {
  const { user: currentUser } = useAuth();
  const { users, deleteUser, updateUser, resetPassword } = useData();
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showBulkUpload, setShowBulkUpload] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('');
  const [showResetPassword, setShowResetPassword] = useState<string | null>(null);

  // Filter users based on current user role
  const getFilteredUsers = () => {
    let filteredUsers = users;

    if (currentUser?.role === 'manager') {
      // Managers can only see their team members and themselves
      filteredUsers = users.filter(u => 
        u.managerId === currentUser.id || u.id === currentUser.id
      );
    } else if (currentUser?.role === 'admin') {
      // Admins can see all users except owners
      filteredUsers = users.filter(u => u.role !== 'owner');
    }
    // Owners can see all users

    // Apply search and filters
    if (searchTerm) {
      filteredUsers = filteredUsers.filter(user =>
        user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.email.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (roleFilter) {
      filteredUsers = filteredUsers.filter(user => user.role === roleFilter);
    }

    return filteredUsers;
  };

  const filteredUsers = getFilteredUsers();

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case 'owner': return 'bg-purple-100 text-purple-800';
      case 'admin': return 'bg-blue-100 text-blue-800';
      case 'manager': return 'bg-green-100 text-green-800';
      case 'user': return 'bg-secondary-100 text-secondary-800';
      default: return 'bg-secondary-100 text-secondary-800';
    }
  };

  const getManagerName = (managerId?: string) => {
    if (!managerId) return '-';
    const manager = users.find(u => u.id === managerId);
    return manager ? manager.name : 'Unknown';
  };

  const handleDelete = (userId: string) => {
    if (window.confirm('Are you sure you want to delete this user?')) {
      deleteUser(userId);
    }
  };

  const handleToggleActive = (userId: string, isActive: boolean) => {
    updateUser(userId, { isActive: !isActive });
  };

  const handleResetPassword = (userId: string) => {
    const newPassword = 'password123'; // In real app, generate secure password
    resetPassword(userId, newPassword);
    setShowResetPassword(null);
    toast.success(`Password reset to: ${newPassword}`);
  };

  const canEditUser = (user: User) => {
    if (currentUser?.role === 'owner') return true;
    if (currentUser?.role === 'admin' && user.role !== 'owner') return true;
    if (currentUser?.role === 'manager' && (user.managerId === currentUser.id || user.id === currentUser.id)) return true;
    return false;
  };

  const canDeleteUser = (user: User) => {
    if (user.id === currentUser?.id) return false; // Can't delete self
    if (currentUser?.role === 'owner' && user.role !== 'owner') return true;
    if (currentUser?.role === 'admin' && user.role !== 'owner' && user.role !== 'admin') return true;
    if (currentUser?.role === 'manager' && user.managerId === currentUser.id) return true;
    return false;
  };

  const roleOptions = [
    { value: '', label: 'All Roles' },
    { value: 'admin', label: 'Admin' },
    { value: 'manager', label: 'Manager' },
    { value: 'user', label: 'User' },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-secondary-900">Users Management</h2>
        <div className="flex space-x-3">
          {(currentUser?.role === 'owner' || currentUser?.role === 'admin') && (
            <Button variant="secondary" onClick={() => setShowBulkUpload(true)}>
              <i className="bi bi-upload mr-2"></i>
              Bulk Upload
            </Button>
          )}
          <Button onClick={() => setShowCreateModal(true)}>
            <i className="bi bi-plus-lg mr-2"></i>
            Add User
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Input
            placeholder="Search users..."
            value={searchTerm}
            onChange={setSearchTerm}
          />
          <Select
            value={roleFilter}
            onChange={setRoleFilter}
            options={roleOptions}
            placeholder="Filter by role"
          />
          <Button
            variant="secondary"
            onClick={() => {
              setSearchTerm('');
              setRoleFilter('');
            }}
          >
            <i className="bi bi-arrow-clockwise mr-2"></i>
            Reset
          </Button>
        </div>
      </Card>

      {/* Users Table */}
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-secondary-200">
                <th className="text-left py-3 px-4 font-semibold text-secondary-900">User</th>
                <th className="text-left py-3 px-4 font-semibold text-secondary-900">Role</th>
                <th className="text-left py-3 px-4 font-semibold text-secondary-900">Manager</th>
                <th className="text-left py-3 px-4 font-semibold text-secondary-900">Status</th>
                <th className="text-left py-3 px-4 font-semibold text-secondary-900">Created</th>
                <th className="text-left py-3 px-4 font-semibold text-secondary-900">Last Login</th>
                <th className="text-left py-3 px-4 font-semibold text-secondary-900">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.map((user) => (
                <tr key={user.id} className="border-b border-secondary-100 hover:bg-secondary-50 transition-colors duration-200">
                  <td className="py-3 px-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-primary-600 rounded-full flex items-center justify-center">
                        <span className="text-white text-sm font-medium">
                          {user.name.charAt(0).toUpperCase()}
                        </span>
                      </div>
                      <div>
                        <p className="font-medium text-secondary-900">{user.name}</p>
                        <p className="text-sm text-secondary-600">{user.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getRoleBadgeColor(user.role)}`}>
                      {user.role.toUpperCase()}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-sm text-secondary-900">
                    {getManagerName(user.managerId)}
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center space-x-2">
                      <div className={`w-2 h-2 rounded-full ${user.isActive ? 'bg-green-500' : 'bg-red-500'}`}></div>
                      <span className="text-sm text-secondary-900">
                        {user.isActive ? 'Active' : 'Inactive'}
                      </span>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-sm text-secondary-600">
                    {new Date(user.createdAt).toLocaleDateString()}
                  </td>
                  <td className="py-3 px-4 text-sm text-secondary-600">
                    {user.lastLogin ? new Date(user.lastLogin).toLocaleDateString() : 'Never'}
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex space-x-2">
                      {canEditUser(user) && (
                        <button
                          onClick={() => setEditingUser(user)}
                          className="text-primary-600 hover:text-primary-700 transition-colors duration-200"
                          title="Edit user"
                        >
                          <i className="bi bi-pencil"></i>
                        </button>
                      )}
                      
                      {(currentUser?.role === 'admin' || currentUser?.role === 'owner') && user.id !== currentUser.id && (
                        <button
                          onClick={() => setShowResetPassword(user.id)}
                          className="text-yellow-600 hover:text-yellow-700 transition-colors duration-200"
                          title="Reset password"
                        >
                          <i className="bi bi-key"></i>
                        </button>
                      )}

                      {canEditUser(user) && user.id !== currentUser?.id && (
                        <button
                          onClick={() => handleToggleActive(user.id, user.isActive)}
                          className={`transition-colors duration-200 ${
                            user.isActive 
                              ? 'text-orange-600 hover:text-orange-700' 
                              : 'text-green-600 hover:text-green-700'
                          }`}
                          title={user.isActive ? 'Deactivate user' : 'Activate user'}
                        >
                          <i className={`bi ${user.isActive ? 'bi-pause-circle' : 'bi-play-circle'}`}></i>
                        </button>
                      )}

                      {canDeleteUser(user) && (
                        <button
                          onClick={() => handleDelete(user.id)}
                          className="text-red-600 hover:text-red-700 transition-colors duration-200"
                          title="Delete user"
                        >
                          <i className="bi bi-trash"></i>
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {filteredUsers.length === 0 && (
            <div className="text-center py-8">
              <i className="bi bi-people text-4xl text-secondary-400 mb-4"></i>
              <p className="text-secondary-600">No users found</p>
            </div>
          )}
        </div>
      </Card>

      {/* Create User Modal */}
      <Modal
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        title="Create New User"
        size="lg"
      >
        <UserForm
          onSubmit={() => setShowCreateModal(false)}
          onCancel={() => setShowCreateModal(false)}
        />
      </Modal>

      {/* Edit User Modal */}
      <Modal
        isOpen={!!editingUser}
        onClose={() => setEditingUser(null)}
        title="Edit User"
        size="lg"
      >
        {editingUser && (
          <UserForm
            user={editingUser}
            onSubmit={() => setEditingUser(null)}
            onCancel={() => setEditingUser(null)}
          />
        )}
      </Modal>

      {/* Reset Password Modal */}
      <Modal
        isOpen={!!showResetPassword}
        onClose={() => setShowResetPassword(null)}
        title="Reset Password"
        size="sm"
      >
        <div className="text-center space-y-4">
          <i className="bi bi-key text-4xl text-yellow-600"></i>
          <p className="text-secondary-700">
            Are you sure you want to reset this user's password?
          </p>
          <p className="text-sm text-secondary-600">
            The new password will be: <strong>password123</strong>
          </p>
          <div className="flex justify-center space-x-3">
            <Button variant="secondary" onClick={() => setShowResetPassword(null)}>
              Cancel
            </Button>
            <Button 
              variant="danger" 
              onClick={() => showResetPassword && handleResetPassword(showResetPassword)}
            >
              Reset Password
            </Button>
          </div>
        </div>
      </Modal>

      {/* Bulk Upload Modal */}
      <Modal
        isOpen={showBulkUpload}
        onClose={() => setShowBulkUpload(false)}
        title="Bulk Upload Users"
        size="lg"
      >
        <BulkUpload type="users" onClose={() => setShowBulkUpload(false)} />
      </Modal>
    </div>
  );
};

export default UsersManagement;
