import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { User } from '../../types';
import Input from '../common/Input';
import Select from '../common/Select';
import Button from '../common/Button';

interface UserFormProps {
  user?: User;
  onSubmit: () => void;
  onCancel: () => void;
}

const UserForm: React.FC<UserFormProps> = ({ user: editUser, onSubmit, onCancel }) => {
  const { user: currentUser } = useAuth();
  const { users, addUser, updateUser } = useData();
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    role: 'user' as 'admin' | 'manager' | 'user',
    managerId: '',
    isActive: true,
  });

  useEffect(() => {
    if (editUser) {
      setFormData({
        name: editUser.name,
        email: editUser.email,
        role: editUser.role as 'admin' | 'manager' | 'user',
        managerId: editUser.managerId || '',
        isActive: editUser.isActive,
      });
    }
  }, [editUser]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const userData = {
      ...formData,
      managerId: formData.managerId || undefined,
    };

    if (editUser) {
      updateUser(editUser.id, userData);
    } else {
      addUser(userData);
    }
    
    onSubmit();
  };

  const getRoleOptions = () => {
    if (currentUser?.role === 'owner') {
      return [
        { value: 'admin', label: 'Admin' },
        { value: 'manager', label: 'Manager' },
        { value: 'user', label: 'User' },
      ];
    }
    if (currentUser?.role === 'admin') {
      return [
        { value: 'manager', label: 'Manager' },
        { value: 'user', label: 'User' },
      ];
    }
    if (currentUser?.role === 'manager') {
      return [
        { value: 'user', label: 'User' },
      ];
    }
    return [];
  };

  const getManagerOptions = () => {
    if (formData.role === 'user') {
      return users
        .filter(u => u.role === 'manager' && u.id !== editUser?.id)
        .map(u => ({ value: u.id, label: u.name }));
    }
    return [];
  };

  const roleOptions = getRoleOptions();
  const managerOptions = getManagerOptions();

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input
          label="Full Name"
          value={formData.name}
          onChange={(value) => setFormData(prev => ({ ...prev, name: value }))}
          placeholder="Enter full name"
          required
        />

        <Input
          label="Email Address"
          type="email"
          value={formData.email}
          onChange={(value) => setFormData(prev => ({ ...prev, email: value }))}
          placeholder="Enter email address"
          required
        />

        <Select
          label="Role"
          value={formData.role}
          onChange={(value) => setFormData(prev => ({ 
            ...prev, 
            role: value as any,
            managerId: value !== 'user' ? '' : prev.managerId
          }))}
          options={roleOptions}
          required
        />

        {formData.role === 'user' && managerOptions.length > 0 && (
          <Select
            label="Manager"
            value={formData.managerId}
            onChange={(value) => setFormData(prev => ({ ...prev, managerId: value }))}
            options={managerOptions}
            placeholder="Select a manager"
          />
        )}
      </div>

      <div className="flex items-center space-x-2">
        <input
          type="checkbox"
          id="isActive"
          checked={formData.isActive}
          onChange={(e) => setFormData(prev => ({ ...prev, isActive: e.target.checked }))}
          className="rounded border-secondary-300 text-primary-600 focus:ring-primary-500"
        />
        <label htmlFor="isActive" className="text-sm font-medium text-secondary-700">
          Active User
        </label>
      </div>

      <div className="flex justify-end space-x-3 pt-4">
        <Button variant="secondary" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit">
          {editUser ? 'Update User' : 'Create User'}
        </Button>
      </div>
    </form>
  );
};

export default UserForm;
