export interface User {
  id: string;
  name: string;
  email: string;
  role: 'owner' | 'admin' | 'manager' | 'user';
  managerId?: string;
  createdAt: string;
  lastLogin?: string;
  isActive: boolean;
}

export interface Lead {
  id: string;
  name: string;
  email: string;
  mobile: string;
  status: 'hot' | 'warm' | 'cold';
  stage: 'initial' | 'negotiation' | 'follow-up' | 'closed-won' | 'closed-lost';
  assignedTo: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  notes?: string;
  value?: number;
}

export interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  isLoading: boolean;
}

export interface DashboardStats {
  totalLeads: number;
  hotLeads: number;
  closedWon: number;
  conversionRate: number;
  teamMembers: number;
  monthlyTarget: number;
}
