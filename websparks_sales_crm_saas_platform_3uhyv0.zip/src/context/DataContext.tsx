import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Lead } from '../types';
import toast from 'react-hot-toast';

interface DataContextType {
  users: User[];
  leads: Lead[];
  addUser: (user: Omit<User, 'id' | 'createdAt'>) => void;
  updateUser: (id: string, updates: Partial<User>) => void;
  deleteUser: (id: string) => void;
  addLead: (lead: Omit<Lead, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateLead: (id: string, updates: Partial<Lead>) => void;
  deleteLead: (id: string) => void;
  bulkUploadUsers: (users: Omit<User, 'id' | 'createdAt'>[]) => void;
  bulkUploadLeads: (leads: Omit<Lead, 'id' | 'createdAt' | 'updatedAt'>[]) => void;
  resetPassword: (userId: string, newPassword: string) => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const useData = () => {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};

const initialUsers: User[] = [
  {
    id: '1',
    name: 'John Owner',
    email: 'owner@company.com',
    role: 'owner',
    createdAt: '2024-01-01',
    isActive: true,
  },
  {
    id: '2',
    name: 'Sarah Admin',
    email: 'admin@company.com',
    role: 'admin',
    createdAt: '2024-01-02',
    isActive: true,
  },
  {
    id: '3',
    name: 'Mike Manager',
    email: 'manager@company.com',
    role: 'manager',
    createdAt: '2024-01-03',
    isActive: true,
  },
  {
    id: '4',
    name: 'Lisa User',
    email: 'user@company.com',
    role: 'user',
    managerId: '3',
    createdAt: '2024-01-04',
    isActive: true,
  },
];

const initialLeads: Lead[] = [
  {
    id: '1',
    name: 'Acme Corporation',
    email: 'contact@acme.com',
    mobile: '+1234567890',
    status: 'hot',
    stage: 'negotiation',
    assignedTo: '4',
    createdBy: '3',
    createdAt: '2024-01-10',
    updatedAt: '2024-01-15',
    value: 50000,
  },
  {
    id: '2',
    name: 'Tech Solutions Inc',
    email: 'info@techsolutions.com',
    mobile: '+1234567891',
    status: 'warm',
    stage: 'follow-up',
    assignedTo: '4',
    createdBy: '4',
    createdAt: '2024-01-12',
    updatedAt: '2024-01-16',
    value: 25000,
  },
];

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [users, setUsers] = useState<User[]>(initialUsers);
  const [leads, setLeads] = useState<Lead[]>(initialLeads);

  useEffect(() => {
    const savedUsers = localStorage.getItem('crmUsers');
    const savedLeads = localStorage.getItem('crmLeads');
    
    if (savedUsers) {
      setUsers(JSON.parse(savedUsers));
    }
    if (savedLeads) {
      setLeads(JSON.parse(savedLeads));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('crmUsers', JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem('crmLeads', JSON.stringify(leads));
  }, [leads]);

  const addUser = (userData: Omit<User, 'id' | 'createdAt'>) => {
    const newUser: User = {
      ...userData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
    };
    setUsers(prev => [...prev, newUser]);
    toast.success('User created successfully');
  };

  const updateUser = (id: string, updates: Partial<User>) => {
    setUsers(prev => prev.map(user => 
      user.id === id ? { ...user, ...updates } : user
    ));
    toast.success('User updated successfully');
  };

  const deleteUser = (id: string) => {
    setUsers(prev => prev.filter(user => user.id !== id));
    toast.success('User deleted successfully');
  };

  const addLead = (leadData: Omit<Lead, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newLead: Lead = {
      ...leadData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    setLeads(prev => [...prev, newLead]);
    toast.success('Lead created successfully');
  };

  const updateLead = (id: string, updates: Partial<Lead>) => {
    setLeads(prev => prev.map(lead => 
      lead.id === id ? { ...lead, ...updates, updatedAt: new Date().toISOString() } : lead
    ));
    toast.success('Lead updated successfully');
  };

  const deleteLead = (id: string) => {
    setLeads(prev => prev.filter(lead => lead.id !== id));
    toast.success('Lead deleted successfully');
  };

  const bulkUploadUsers = (usersData: Omit<User, 'id' | 'createdAt'>[]) => {
    const newUsers = usersData.map(userData => ({
      ...userData,
      id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
      createdAt: new Date().toISOString(),
    }));
    setUsers(prev => [...prev, ...newUsers]);
    toast.success(`${newUsers.length} users uploaded successfully`);
  };

  const bulkUploadLeads = (leadsData: Omit<Lead, 'id' | 'createdAt' | 'updatedAt'>[]) => {
    const newLeads = leadsData.map(leadData => ({
      ...leadData,
      id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }));
    setLeads(prev => [...prev, ...newLeads]);
    toast.success(`${newLeads.length} leads uploaded successfully`);
  };

  const resetPassword = (userId: string, newPassword: string) => {
    // In a real app, this would make an API call
    toast.success('Password reset successfully');
  };

  return (
    <DataContext.Provider value={{
      users,
      leads,
      addUser,
      updateUser,
      deleteUser,
      addLead,
      updateLead,
      deleteLead,
      bulkUploadUsers,
      bulkUploadLeads,
      resetPassword,
    }}>
      {children}
    </DataContext.Provider>
  );
};
