import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, AuthContextType } from '../types';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

const mockUsers: User[] = [
  {
    id: '1',
    name: 'John Owner',
    email: 'owner@company.com',
    role: 'owner',
    createdAt: '2024-01-01',
    isActive: true,
  },
  {
    id: '2',
    name: 'Sarah Admin',
    email: 'admin@company.com',
    role: 'admin',
    createdAt: '2024-01-02',
    isActive: true,
  },
  {
    id: '3',
    name: 'Mike Manager',
    email: 'manager@company.com',
    role: 'manager',
    createdAt: '2024-01-03',
    isActive: true,
  },
  {
    id: '4',
    name: 'Lisa User',
    email: 'user@company.com',
    role: 'user',
    managerId: '3',
    createdAt: '2024-01-04',
    isActive: true,
  },
];

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => window.setTimeout(resolve, 1000));
    
    const foundUser = mockUsers.find(u => u.email === email);
    if (foundUser && password === 'password123') {
      const userWithLogin = { ...foundUser, lastLogin: new Date().toISOString() };
      setUser(userWithLogin);
      localStorage.setItem('currentUser', JSON.stringify(userWithLogin));
      setIsLoading(false);
      return true;
    }
    
    setIsLoading(false);
    return false;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('currentUser');
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
};
